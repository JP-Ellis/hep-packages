char * WORK="/home/pukhov/MICROMEGAS/2019/micromegas_5.0.9/QQ/work";
